package com.mouadh.backend.service;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import com.mouadh.backend.dto.auth.AuthResponse;
import com.mouadh.backend.dto.auth.AuthUserResponse;
import com.mouadh.backend.dto.auth.BuyerRegisterRequest;
import com.mouadh.backend.dto.auth.ChefRegisterRequest;
import com.mouadh.backend.dto.auth.LoginRequest;
import com.mouadh.backend.model.BaseUser;
import com.mouadh.backend.model.Buyer;
import com.mouadh.backend.model.Chef;
import com.mouadh.backend.repository.BuyerRepository;
import com.mouadh.backend.repository.ChefRepository;
import com.mouadh.backend.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AuthService {

    private final BuyerRepository buyerRepository;
    private final ChefRepository chefRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(BuyerRepository buyerRepository,
                       ChefRepository chefRepository,
                       PasswordEncoder passwordEncoder,
                       JwtService jwtService) {
        this.buyerRepository = buyerRepository;
        this.chefRepository = chefRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    // ---------------- REGISTER BUYER ----------------
    public AuthResponse registerBuyer(BuyerRegisterRequest request) {

        if (emailExists(request.getEmail())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already in use");
        }

        Buyer buyer = new Buyer();
        buyer.setName(request.getName());
        buyer.setEmail(request.getEmail());
        buyer.setPassword(passwordEncoder.encode(request.getPassword()));
        buyer.setCreatedAt(LocalDateTime.now());

        Buyer savedBuyer = buyerRepository.save(buyer);
        return buildAuthResponse(savedBuyer);
    }

    // ---------------- REGISTER CHEF ----------------
    public AuthResponse registerChef(ChefRegisterRequest request) {

        if (emailExists(request.getEmail())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already in use");
        }

        Chef chef = new Chef();
        chef.setName(request.getName());
        chef.setEmail(request.getEmail());
        chef.setPassword(passwordEncoder.encode(request.getPassword()));
        chef.setCreatedAt(LocalDateTime.now());
        chef.setTotalEarnings(0.0);

        Chef savedChef = chefRepository.save(chef);
        return buildAuthResponse(savedChef);
    }

    // ---------------- LOGIN ----------------
    public AuthResponse login(LoginRequest request) {

        BaseUser user = buyerRepository.findByEmail(request.getEmail())
                .map(b -> (BaseUser) b)
                .or(() -> chefRepository.findByEmail(request.getEmail())
                        .map(c -> (BaseUser) c))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid credentials");
        }

        return buildAuthResponse(user);
    }

    // ---------------- UTILITY ----------------
    private AuthResponse buildAuthResponse(BaseUser user) {
        String role = (user instanceof Chef) ? "CHEF" : "BUYER";
        String authorityRole = "ROLE_" + role;
        String token = jwtService.generateToken(user.getId(), authorityRole);
        AuthUserResponse authUser = new AuthUserResponse(
                user.getId(),
                user.getEmail(),
                user.getName(),
                role,
                user.getCreatedAt()
        );
        return new AuthResponse(token, authUser);
    }

    private boolean emailExists(String email) {
        return buyerRepository.findByEmail(email).isPresent()
                || chefRepository.findByEmail(email).isPresent();
    }
}
