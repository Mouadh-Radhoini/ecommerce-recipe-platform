import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { environment } from '../../../environments/environment';
import { AuthService } from '../services/auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
    const authService = inject(AuthService);
    const token = authService.getToken();

    // Skip auth header for auth endpoints
    if (req.url.includes('/api/auth/login') || req.url.includes('/api/auth/register')) {
        return next(req);
    }

    // Add authorization header if token exists
    if (token && req.url.startsWith(`${environment.apiUrl}/api/`)) {
        const clonedReq = req.clone({
            setHeaders: {
                Authorization: `Bearer ${token}`
            }
        });
        return next(clonedReq);
    }

    return next(req);
};
